# 决策与踩坑日志

只追加、不改写历史条目。回退另开新条，旧条目标「已回退」。  
**现行规则**以 [CONTEXT.md](CONTEXT.md) / [ARCHITECTURE.md](ARCHITECTURE.md) 为准；本文件只记结论与禁令。

改口径、解析路径、主题机制、工作目录之前先搜本文。

### 模板

```
### D-编号  短标题
- 状态：已采纳 / 已回退 / 已知限制
- 类型：口径 | 架构 | 工具链 | 流程
- 日期 / 版本：
- 背景：
- 结论：
- 禁止：
- 现行文档：
```

---

## 统计口径

### D-1  统计默认订单级，禁止记录级默算

- 状态：已采纳
- 类型：口径
- 日期 / 版本：v5.1 审计修复（原 README 问题 1、6、8）
- 背景：一张单可经多门岗产生多行。`chart_status`、趋势、部门 TOP、KPI 超时未接收、Excel 导出等一度按行计数，与 GDMS 卡按单计数不一致，同一指标两套数字。
- 结论：看板数字一律按 `computeOrders()` 的单。记录级仅允许副标题「记录 N 条」、明细表、动态栏、以及明确标注的「特保记录数」。
- 禁止：新指标默认 `rows.filter` 当主数字；`statusDist` 等不得再用记录级。
- 现行文档：CONTEXT §2、§4

### D-2  泛称「超时」= 放行超时 ∪ 接收超时

- 状态：已采纳
- 类型：口径
- 日期 / 版本：v5.1（原问题 2、3、6）
- 背景：`timeoutAll` 一度漏「已接收但接收时超时」；`chart_status` 的「接收超时」实际只统计了「超时未接收」子集；日趋势「总超时」同样漏项。
- 结论：广义超时 = `o.放行超时 || o.接收超时`。标题写「放行超时By××」的卡仍只用放行超时。接收超时含「已接收但超时」与「超时未接收」两个互斥子集。
- 禁止：用「超时未接收」冒充「接收超时」总数。
- 现行文档：CONTEXT §3 超时分类

### D-3  NPI超时拆成特保物料 + 特保机台，禁止两格同一数据

- 状态：已采纳
- 类型：口径
- 日期 / 版本：v5.1（原问题 4、7）
- 背景：`gdms_summary` 第 6 格 NPI超时与第 7 格特保物料超时曾指向同一字段；第 8 格标签错、且未过滤特保。`timeoutGeneral` 按繁简关键词两次 filter 可能重复计数，后确认为死代码已删。
- 结论：NPI = 特保单。第 7 格 = 特保 ∧ 广义超时 ∧ 分类含 A级物料；第 8 格 = 特保 ∧ 广义超时 ∧ 分类含机台。两格互斥，之和 = NPI超时。
- 禁止：两格展示同一计数；非特保机台计入「特保机台超时」。
- 现行文档：CONTEXT §4 gdms_summary

### D-4  一单一种物品分类，禁止 split("/")

- 状态：已采纳
- 类型：口径
- 日期 / 版本：v5.1（原问题 5）
- 背景：`materialClass` split 后检查子项、`timeoutByCat` 只取 `[0]`、详情图不 split，三种拆法并存。业务上建单后种类固定，多行只是过门岗，不会出现 `/` 多值。
- 结论：`computeOrders()` 对分类 `find(Boolean)` 取首个非空；分组与 includes 都直取 `o.物品分类`。
- 禁止：对物品分类 `split("/")` 再统计。
- 现行文档：CONTEXT §2；演示数据 / `gen_monitor_data_v3.py` 必须整单固定分类

### D-5  特保只认单号前缀 WF9897

- 状态：已采纳
- 类型：口径
- 日期 / 版本：v2.2.0
- 背景：旧版用物品类型关键词（新产品A级物料/机台）或单号含 `WF8888`。与现场安保单号规则不符，误判/漏判。
- 结论：`isSpecialOrder` = `放行单号.startsWith("WF9897")`。普通单演示前缀 `WF7501`。
- 禁止：再用 WF8888 或物品类型关键词判定特保。`docs/archive/scripts/gen_monitor_data.py` 等产出的 WF8888 文件不能当特保测试集。
- 现行文档：CONTEXT §3；CONFIG.特保单号前缀

### D-6  结案率分母排除「在途未超时」

- 状态：已采纳
- 类型：口径
- 日期 / 版本：v2.1.0
- 背景：曾用「接收完成率」或把尚在正常运输的单据计入分母，会扭曲时效。
- 结论：分子 = 已到达且未放行超时；分母 = 结案完成 + 到达超时 + 在途超时。在途未超时不纳入。
- 禁止：把结果未知的在途未超时单打进完成率分母。
- 现行文档：CONTEXT §3 放行结案完成率

### D-7  接收超时按接收人部门考核，不按申请部门

- 状态：已采纳
- 类型：口径
- 日期 / 版本：v5.2.0
- 背景：业务确认责任主体是收货方。导出有「接收人部門」列，看板一度未映射，无法按接收部门分析。
- 结论：映射 `接收人部门`；订单取该单首个非空；卡片 `gdms_receive_dept` 按广义接收超时 groupBy 该字段。
- 禁止：用申请部门代替接收部门做接收超时问责。
- 现行文档：CONTEXT §4 gdms_receive_dept

---

## 解析与性能

### D-8  智能跳过标题行，取第一个有数据的 Sheet

- 状态：已采纳
- 类型：架构
- 日期 / 版本：表头 v2.2.0；空 Sheet v5.4.0
- 背景：导出常有首行合并标题；有时第一张是空汇总页。固定 `SheetNames[0]` + `decode_range(ws['!ref'])` 会 TypeError，表现为「解析失败」且无提示。
- 结论：`findHeaderRow()` 向下最多 20 行、命中 ≥2 个别名即表头。`firstNonEmptySheet()` 跳过空表。
- 禁止：写死只读第一张表且假定 `!ref` 一定存在。
- 现行文档：ARCHITECTURE §1、§3

### D-9  大文件主线程分块 + 引导转存 CSV

- 状态：已采纳
- 类型：架构
- 日期 / 版本：v3.0.1 / v3.1
- 背景：`XLSX.read` + 全表 `sheet_to_json` 冻住主线程，进度条停、浏览器「页面无响应」。
- 结论：提取/标准化分块让出主线程；≥3 万行关动画、表格虚拟滚动。xlsx 解析后提供「转存 CSV」（约 35 倍）。`XLSX.read` 本身仍可能阻塞数秒，属已知限制。
- 禁止：为了进度条再对全表解析两次。
- 现行文档：ARCHITECTURE §1、§6

### D-10  禁止内联 xlsx 库（已回退）

- 状态：已回退（相对 v3.1 的「内联」决策）
- 类型：工具链
- 日期 / 版本：v3.1 引入；v5.4 回退
- 背景：为让 file:// 下 Worker 能 `importScripts`，曾把 xlsx 内联进 HTML（+861KB）。后发现内联副本缺 37 字节，主线程与 Worker 都语法错误 → xlsx 解析失败而 CSV 正常。
- 结论：改回 `<script src="./lib/xlsx.full.min.js">`。不要再把大型库内联进主 HTML。
- 禁止：为 Worker 再次内联 xlsx。
- 现行文档：ARCHITECTURE §1 解析线程

### D-11  file:// 下 Worker 默认关闭

- 状态：已采纳
- 类型：工具链
- 日期 / 版本：v5.4.0
- 背景：xlsx 改回外部文件后，blob Worker 的相对路径基于 blob URL，无法 `importScripts` `./lib/xlsx`。
- 结论：`window.__workerDisabled = true`，走主线程分块。Worker 代码保留，仅 HTTP 部署可开。
- 禁止：在未解决 file:// importScripts 之前默认开启 Worker。
- 现行文档：ARCHITECTURE §1

### D-12  性能模式禁止 location.reload()

- 状态：已采纳
- 类型：架构
- 日期 / 版本：v5.4.0
- 背景：file:// 下 `reload()` 触发 Chrome 对 frame 的 unsafe URL 警告。
- 结论：就地改 `PERF`、应用 `perf-lite` class、有数据则 `renderAll()`。
- 禁止：用整页刷新作为切性能档的手段。
- 现行文档：ARCHITECTURE §3 PERF

---

## 主题与视图

### D-13  主题外挂 style/，探测不得执行图表 JS

- 状态：已采纳
- 类型：架构
- 日期 / 版本：v5.5 插件化；v5.6 加固
- 背景：Qoder 线把 10/5 套风格烤进单 HTML（`v5.1-themes` / `v5.2-styles`）。DSH 改为 `style/` 插件。中途踩过：① 探测用 `<link>` 未标 `data-probe`，Material3 一进页面就生效且切不回默认；② 探测阶段加载全部主题 JS，多层拦截 `echarts.init` 卡死。
- 结论：主题 = css + 可选 charts.js，登记 `THEME_REGISTRY`。探测只测 css；JS 仅在 `applyTheme` 时加载。探测资源必须 `data-probe` 并在完成后移除。切主题清理 `_themeCleanup` 并恢复原始 `echarts.init`。探测加 5 秒超时。
- 禁止：再复制 `dashboard-release-monitor-v5.x-themes.html` 当交付物；探测阶段执行主题 JS；探测 CSS 不带标记。
- 现行文档：ARCHITECTURE §5、§7.4

### D-14  视图可导出为 views/*.js，不写进主文件

- 状态：已采纳
- 类型：架构
- 日期 / 版本：v5.5.0
- 背景：同事间分享布局若只能口播坐标，或把布局写死进 HTML，无法在 file:// 下热插拔。
- 结论：`VIEW_PLUGIN` 协议 + `VIEW_REGISTRY` 登记。未附带 `views/` 时仅内置 5 套预设。
- 禁止：为分享一个布局而 fork 主 HTML。
- 现行文档：ARCHITECTURE §5、§7.5

---

## 协作与版本

### D-15  唯一工作树是本仓库；Qoder 目录归档

- 状态：已采纳
- 类型：流程
- 日期 / 版本：2026-09-11 文档整改时确认
- 背景：同一项目被不同 agent 写在 `液态玻璃看板Qoder` 与 `DSH_数据看板`。共同主干到 v5.1 后分叉：Qoder 做主题内联实验且 README 冻在 v5.1；DSH 继续业务到 v5.6。两边互不感知。
- 结论：业务与文档只在本仓库改。Qoder 仅作视觉实验只读归档（配色可迁入 `style/`，不要在那边改 `computeStats`）。
- 禁止：再开第三个「看板副本」平行开发；在 Qoder 目录改口径或主流程。
- 现行文档：README 顶部；AGENT 硬禁令

### D-16  版本号不得用同一号表示两件无关的事

- 状态：已采纳
- 类型：流程
- 日期 / 版本：2026-09-11 确认（事故发生在 2026-08）
- 背景：DSH 的 v5.2 = 接收超时 By 接收部门（业务）。Qoder 的 `v5.2-styles.html` = 五种深度设计风格。口头说「v5.2」会对不上。
- 结论：SemVer 仍按 README 旧规范（MAJOR 新模块 / MINOR 兼容增强 / PATCH 修复）。主文件名 `dashboard-release-monitor-v{N.M}.html`。同一号只能有一种含义；风格实验用后缀（`-themes` / `-styles`）或主题插件，不要占用下一个业务 MINOR。
- 禁止：用 `v5.x` 同时当业务版和纯视觉 fork 的版本号。
- 现行文档：README 当前版本字段；AGENT 硬禁令

### D-17  文档中枢是短文件，不是超长唯一 README

- 状态：已采纳
- 类型：流程
- 日期 / 版本：2026-09-11
- 背景：原 README ~1270 行自称唯一权威，但顶部仍写 v5.5，代码已到未提交的 v5.6；agent 读不完或读到过期信息。
- 结论：README 只做路牌。业务 → CONTEXT，结构/扩展 → ARCHITECTURE，纪律 → AGENT，历史 → 本文件。旧全文只读存档于 `docs/archive/README-项目管理文档-v5.5.md`。
- 禁止：再把十章内容堆回 README；禁止改代码却不改 README 顶部版本行。
- 现行文档：README 文档索引

### D-18  顶栏只留状态，工具进右侧抽屉；不要常驻左栏

- 状态：已采纳
- 类型：架构
- 日期 / 版本：v5.6.0（2026-09-11 顶栏改版）
- 背景：顶栏一度横排视图/主题/深浅色/性能/导出/编辑，挤在一起。曾考虑左侧可收起功能栏。本看板是单页监控画布，那些是低频动作不是页面导航；常驻左栏会挤窄 12 列卡片。展开钮若只做箭头且写死黑底，在玻璃/新拟态/瑞士等主题里会看不清或与配色冲突；加「功能」文字又破坏简洁。
- 结论：默认顶栏 = 标题 + 状态芯片 + 右侧圆形箭头。工具（含 iOS 式深浅色/流畅开关、主题、视图、导出、编辑布局）放进可动画展开的抽屉，同一行排列。空闲态抽屉按钮跟各主题普通按钮配色；展开态才用强调色。只保留图标。
- 禁止：把工具做成常驻左侧栏；抽屉按钮写死黑底或加「功能/收起」文案；把主题/导出再铺回默认顶栏。
- 现行文档：ARCHITECTURE §顶栏壳、§7.4 第 5 步

### D-19  提交 git 前必须先同步文档；壳层改动也算

- 状态：已采纳
- 类型：流程
- 日期 / 版本：2026-09-11（v5.6 顶栏抽屉已推代码后才补文档）
- 背景：AGENT 原先只写「改了口径或机制要写 DECISIONS」。顶栏改成抽屉被当成纯 UI，用户一说提交就把 HTML/CSS 推上 GitHub，文档仍写「顶栏一排按钮 / 点顶栏切流畅模式」。下一任 agent 会按过期壳层改。
- 结论：任何会改变「人怎么用、agent 去哪改」的提交，先按 AGENT「改了什么 → 改哪份文档」补完再 commit。顶栏、抽屉、开关、主题按钮三态属于 ARCHITECTURE 现行壳，不是可选项。用户催提交也不能先推代码后补文档。
- 禁止：以「只是 UI」「用户说先提交」跳过文档；把壳层说明留在聊天记录里当文档。
- 现行文档：AGENT 硬禁令与提交前检查表

### D-20  每次提交用 CHANGELOG 记流水；未做完写「进行中」

- 状态：已采纳
- 类型：流程
- 日期 / 版本：2026-09-11
- 背景：用户习惯是「满意了就提交」或「今天先停、明天继续也提交」。只有 git message 和现行说明书时，下一班不知道做到哪、改过什么壳。DECISIONS 若变成每日流水会泡肿；CONTEXT / ARCHITECTURE 只应维持现行规则。
- 结论：根目录 [CHANGELOG.md](CHANGELOG.md) 记改动内容（短句、按日）。开工先读「进行中」。未做完必须写清下一步；做完从「进行中」挪走。DECISIONS 仍只收决策与禁令。
- 禁止：用 DECISIONS 当 changelog；提交 WIP 却把「进行中」留空；把长步骤复制进 CHANGELOG。
- 现行文档：CHANGELOG.md；AGENT 对照表第一行与收工第 1 条

### D-21  滞留按流入门岗·订单级；过岗负荷按实际放行门岗·记录级

- 状态：已采纳
- 类型：口径
- 日期 / 版本：v5.6（卡 A / 卡 B）
- 背景：要看出高压岗。流入门岗是目的地排队，实际放行门岗是盖章次数。混在一根柱上会把「堵」和「忙」搅在一起。过货若按单计，一单多跳的忙岗会被看轻。
- 结论：卡 A = 目的地（流入门岗）将到未到的在途单，按单计，再拆超时/未超时。卡 B = 该岗已经盖章的过岗次数（记录级），标题写「次数」。已到达后的超时未接收不算门岗滞留。
- 禁止：流入与实际放行加总成一张「门岗 TOP」；卡 B 主数字用单数却不写明记录级；用 100k 均分门岗集验收高压岗。
- 现行文档：CONTEXT §4 chart_gate_stuck / chart_gate_load

### D-22  KPI 中卡/大卡以 HANDOFF 为视觉规格；数据走 buildKpiProps

- 状态：已采纳
- 类型：架构
- 日期 / 版本：v5.6（2026-09-12）
- 背景：拉大 KPI 后曾用「数字+芯片」填空，视觉不协调。Trae 产出 `kpi-card-redesign/HANDOFF.md` + `index.html` 作为中卡/大卡基准。
- 结论：S 小卡保持原数字逻辑。M/L 按 HANDOFF 模板（中卡三段式、大卡三栏+表头 Tab+环图引导线）。数值只从 `buildKpiProps(id, computeStats())` 取，禁止写死原型里的 202/34。结案率不在这四张业务 KPI 里，仍用水球。规格与原型在 `kpi-card-redesign/`。
- 禁止：中/大卡再退回芯片横条；大卡 Tab 放到内容区右上；环图省略引导线标签；「全部 N 条」用全表行数冒充过滤条数。
- 现行文档：ARCHITECTURE §4 KPI 分档；CONTEXT §4 KPI；kpi-card-redesign/HANDOFF.md

### D-23  网格 24 列 × 行高 48px；旧 12 列布局自动 ×2

- 状态：已采纳
- 类型：架构
- 日期 / 版本：v5.6（2026-09-22）
- 背景：12 列 + 95px 行高拖拽一档跨度大；中/大卡按格子数换模板，格子粗则换档也猛。
- 结论：`GRID_COLS=24`、`GRID_CELL_H=48`。默认 KPI `4×4` 视觉约等于旧 `2×2`。中卡 `h≥6` 或（`w≥10` 且 `h≥5`）；大卡 `w≥12` 且 `h≥8`（半宽，一行两张）。`ensureLayoutV24` 识别 `x+w≤12` 的旧布局并 ×2；`dashLayouts.gridCols=24`。
- 禁止：新写布局仍按 12 列坐标；迁移函数对已是 24 列的布局再乘一次。
- 现行文档：ARCHITECTURE §4

### D-24  多 Agent 串行：设计沙盒 → 人批 HANDOFF → 实现进主文件

- 状态：已采纳
- 类型：流程
- 日期 / 版本：2026-09-22
- 背景：Trae 擅长卡片布局，Grok Build 擅长改主文件业务逻辑。`kpi-card-redesign/` 已验证「原型 + HANDOFF」能交接，但是一次性根目录。若再开 `designs/` 或回 Qoder 目录做设计，会重演 D-15 分叉。GitHub Issue 标签与 Actions 自动开工会绑死 `file://` 本机流程。
- 结论：新原型只写 `docs/prototypes/<slug>/`（`index.html` + `HANDOFF.md`），不是交付物。唯一开工闸门是 HANDOFF 的 `status: approved`（只有用户能改这个字段）。实现 Agent 按 HANDOFF 改主文件，数据走 `buildKpiProps` / `computeStats()`。`kpi-card-redesign/` 作已交付样板留在原处。Issue 标签与 `grok -p` 触发以后再论，不作开工前提。
- 禁止：设计阶段改主 HTML / `CONFIG` / 口径函数；未 approved 就改对应卡片；在仓库根或 Qoder 目录另开原型树；把原型演示数字写进 `computeStats`；用 Issue 标签替代 HANDOFF 状态。
- 现行文档：AGENT 角色节；docs/prototypes/README.md；本条

### D-25  新布局推荐 Issue + design/feat 分支 + PR；标签不替代 HANDOFF

- 状态：已采纳
- 类型：流程
- 日期 / 版本：2026-09-22
- 背景：D-24 把开工闸定在 HANDOFF `approved`。用户希望新布局走 Issue → Trae 分支 → 审核 → `ready-for-build` → Grok PR → 合并关单，但不要让标签成为第二套法律。
- 结论：新布局 / 改主文件推荐：Issue（可选 `design/trae`）→ `design/<slug>` 只交原型 PR → 用户改 HANDOFF 为 `approved` 并合并 → 可选打 `ready-for-build` → Grok 从 `main` 开 `feat/<slug>` 提 PR（开工可把 HANDOFF 改 `implementing`）→ `file://` 验收后合并，HANDOFF 改 `shipped`，关 Issue。**唯一开工闸门仍是 `status: approved`。** 没开 Issue、没打标签不算违禁。改一句文案可直推 `main`。禁止提 `.trae-html-share-packages/` 与 `.uploads/`。
- 禁止：用标签替代 HANDOFF；没有 `approved` 仍改主文件；把没开 Issue 当硬禁令；Actions 被标签自动开工。
- 现行文档：AGENT 「推荐卡片流程」；docs/prototypes/README.md；D-24
